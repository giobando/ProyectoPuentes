``pyfftw.builders`` - Get :class:`~!pyfftw.FFTW` objects using a :mod:`!numpy.fft` like interface
=================================================================================================

.. automodule:: pyfftw.builders
   :members:
   :undoc-members:

   The Functions
   """""""""""""
