:mod:`scipy.fftpack` interface
==============================

.. automodule:: pyfftw.interfaces.scipy_fftpack
   :members: fft, ifft, fftn, ifftn, rfft, irfft, fft2, ifft2, next_fast_len
