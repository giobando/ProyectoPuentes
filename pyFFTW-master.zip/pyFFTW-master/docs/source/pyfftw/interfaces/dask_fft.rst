:mod:`dask.fft` interface
==========================

.. automodule:: pyfftw.interfaces.dask_fft
   :members: fft, ifft, rfft, irfft, hfft, ihfft
